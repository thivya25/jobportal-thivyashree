import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { LandingpageComponent } from './components/landingpage/landingpage.component';
import { HomepageComponent } from './components/homepage/homepage.component';
import { MockinterviewComponent } from './components/mockinterview/mockinterview.component';
import { JobdetailsComponent } from './components/jobdetails/jobdetails.component';
import { ResumereviewComponent } from './components/resumereview/resumereview.component';
import { JobapplicationComponent } from './components/jobapplication/jobapplication.component';

const routes: Routes = [
  { path: '', redirectTo: "landingpage", pathMatch: 'full' },
  {path:"landingpage",component:LandingpageComponent},
  {path:"login",component:LoginComponent},
  {path:"homepage",component:HomepageComponent},
  {path:"mockinterview",component:MockinterviewComponent},
  {path:"jobdetails/:companyid",component:JobdetailsComponent},
  {path:"resumereview",component:ResumereviewComponent},
  {path:"jobapplication",component:JobapplicationComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
