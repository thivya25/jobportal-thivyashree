import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {
  isflag:string='false';
  
  constructor(private router: Router){
    
  }

  
    ngOnInit( isflag:string='false'){
      
      this.isflag =sessionStorage.getItem('userloggedin')
      console.log(isflag)
    }
  loggedout(){

    console.log('infun')
   sessionStorage.removeItem('userloggedin')
   this.router.navigate(['landingpage']);
  
  }

}
