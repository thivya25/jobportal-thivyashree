import { Component } from '@angular/core';
import { Company } from 'src/app/dao/company';


@Component({
  selector: 'app-landingpage',
  templateUrl: './landingpage.component.html',
  styleUrls: ['./landingpage.component.css']
})
export class LandingpageComponent {
item:Company;
datas:any[]=[];
  filteredCompanyList: any;


  ngOnInit(){
    
    let data={companyid:1,companyname:'ACCENTURE',jobrole:'software trainee',jobdescription:'Entry-level position for software trainee responsible for learning and applying programming languages, troubleshooting, and collaborating with team members to develop software solutions.',rating:'4.5',status:'notapplied',location:'chennai',experience:'fresher',salary:'2LPA',url:'http://ACCENTURE.com'}
    let data2= {companyid:2,companyname:'Tech Innovations Inc.',jobrole:'Software Engineer',jobdescription:'Seeking a skilled Software Engineer to join our dynamic team, responsible for developing innovative software solutions and contributing to cutting-edge projects.',rating:'5',status:'notapplied',location:'bangalore',experience:'Entry-level',salary:'6-7LPA',url:'http://Tech Innovations Inc.com'}
    let data3= {companyid:3,companyname:'SalesPro Solutions',jobrole:'Sales Representative',jobdescription:'Join our top-rated team at SalesPro Solutions, where you will drive revenue growth through effective sales strategies and exceptional customer service.',rating:'3',status:'notapplied',location:'delhi',experience:'5 years',salary:'12-15LPA',url:'http://SalesPro Solutionscom'}
    let data4= {companyid:4,companyname:'TalentMasters Ltd.',jobrole:'HR Specialist',jobdescription:'TalentMasters Ltd. is seeking an experienced HR Specialist to oversee recruitment, employee relations, and talent management, fostering a positive workplace culture and ensuring compliance with HR policies and regulations.',rating:'3.8',status:'notapplied',location:'bangalore',experience:'Entry-level',salary:'5-7LPA',url:'http://TalentMasters Ltd.com'}
    let data5=  {companyid:5,companyname:'FinTrust Bank',jobrole:'Financial Analyst',jobdescription:'FinTrust Banks esteemed team as a Financial Analyst, where you will analyze market trends, evaluate investment opportunities, and provide strategic financial insights to drive business growth and optimize performance.',rating:'5',status:'notapplied',location:'mumbai',experience:'fresher',salary:'6-7LPA',url:'http://FinTrust Bank.com'}
    let data6= {companyid:6,companyname:'StrategyWorks Inc',jobrole:'Business Analyst',jobdescription:'StrategyWorks Inc. seeks a skilled Business Analyst to analyze data, identify business opportunities, and provide actionable insights to enhance decision-making and drive organizational success.',rating:'2.5',status:'notapplied',location:'pune',experience:'2 years',salary:'8LPA',url:'http://StrategyWorks Inc.com'}
    localStorage.setItem('1',JSON.stringify(data))
    localStorage.setItem('2',JSON.stringify(data2))
    localStorage.setItem('3',JSON.stringify(data3))
    localStorage.setItem('4',JSON.stringify(data4))
    localStorage.setItem('5',JSON.stringify(data5))
    localStorage.setItem('6',JSON.stringify(data6))
    
    this.dataretrive()
    
    
  }
  dataretrive() {
  
    //this.dataservice.dataretriving()
  let data= JSON.parse(localStorage.getItem('1'));
  let data2= JSON.parse(localStorage.getItem('2'));
  let data3= JSON.parse(localStorage.getItem('3'));
  let data4= JSON.parse(localStorage.getItem('4'));
  let data5= JSON.parse(localStorage.getItem('5'));
  let data6= JSON.parse(localStorage.getItem('6'));
   
    this.datas.push(data,data2,data3,data4,data5,data6)
    console.log(this.datas)

    
  }

isFlag:boolean=false;
  searchfun(text: string){
    if (!text) {
      this.filteredCompanyList = this.datas;
      this.isFlag=!this.isFlag;
      return;
    }
  
    this.filteredCompanyList = this.datas.filter(
      item => item?.companyname.toLowerCase().includes(text.toLowerCase())
    );
    // this.isFlag=!this.isFlag;
  }

  }

  
