import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Company } from 'src/app/dao/company';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent {

 job:Company;
datas:any[]=[];
records:any[]=[]

constructor(private router:Router){}

ngOnInit(){
  

  let data= JSON.parse(localStorage.getItem('1'));
  let data2= JSON.parse(localStorage.getItem('2'));
  let data3= JSON.parse(localStorage.getItem('3'));
  let data4= JSON.parse(localStorage.getItem('4'));
  let data5= JSON.parse(localStorage.getItem('5'));
  let data6= JSON.parse(localStorage.getItem('6'));
   
    this.datas.push(data,data2,data3,data4,data5,data6)
    
   this.records=this.datas.filter(j=>j.status==="notapplied")

  console.log(this.records)

 }
 viewjob(companyid:string) {
  
  
  this.router.navigate(['jobdetails',companyid]);
  }
 
applyForJob(id:string) {
  console.log("in apply")
  let records=this.datas.find(j=>j.companyid===id )
  console.log(records)
  records.status='applied';
  console.log("in apply"+records)
  
localStorage.setItem(id,JSON.stringify(records))
// window.location.reload()
  

 
}



}
