import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Company } from 'src/app/dao/company';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-jobdetails',
  templateUrl: './jobdetails.component.html',
  styleUrls: ['./jobdetails.component.css']
})
export class JobdetailsComponent {

  datas:any[]=[]
  data:Company;
  companyid:string;
  constructor(private activeRoute:ActivatedRoute){

  }


  ngOnInit(){
    let data= JSON.parse(localStorage.getItem('1'));
  let data2= JSON.parse(localStorage.getItem('2'));
  let data3= JSON.parse(localStorage.getItem('3'));
  let data4= JSON.parse(localStorage.getItem('4'));
  let data5= JSON.parse(localStorage.getItem('5'));
  let data6= JSON.parse(localStorage.getItem('6'));
   
    this.datas.push(data,data2,data3,data4,data5,data6)
    this.companyid=this.activeRoute.snapshot.params['companyid'];
    this .displaydata()
     
  }
  displaydata(){
    this.data= JSON.parse(localStorage.getItem(this.companyid));
    
    
    
    

  }
  apply(){
    Swal.fire({
      title: "Do you want to apply for this role ?",
      showCancelButton: true,
      confirmButtonText: "yes",
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        Swal.fire("applied sucessfully!", "", "success");
        this.applyjob()
      } 
    });
  }
  records:any;
applyjob(){
  
  this.data.status='applied';
  console.log(this.data)
  
localStorage.setItem(this.companyid,JSON.stringify(this.data))
}
  referralfun(){
    
    localStorage.setItem(this.data.companyid,JSON.stringify(this.data.url))
  }
}
