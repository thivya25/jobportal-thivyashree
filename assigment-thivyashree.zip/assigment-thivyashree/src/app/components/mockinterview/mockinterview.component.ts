import { Component } from '@angular/core';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-mockinterview',
  templateUrl: './mockinterview.component.html',
  styleUrls: ['./mockinterview.component.css']
})
export class MockinterviewComponent {

  referralList = [
    { name: 'John Doe' },
    { name: 'Jane Smith' },
    // Add more referrals as needed
  ];
 
  interviewDate: Date;

  
  today = new Date().toISOString().split('T')[0];

  
 
  showPopup: boolean = false;

  
  openPopup() {
   
   
    Swal.fire({
      position: "center",
      icon: "success",
      title: "Your mock interview is sheduled on"+" "+this.interviewDate,
      showConfirmButton: false,
      timer: 3000
    });
    console.log('Mock interview scheduled for:', this.interviewDate);
  }

}
