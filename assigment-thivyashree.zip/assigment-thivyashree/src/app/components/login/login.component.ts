import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  constructor( private router: Router, ){}

  useremail:string;
  userpassword:string;
  
  isUserLoggedIn:boolean=false
  validlogin(){
    if(this.useremail=="thivya@gmail.com" && this.userpassword=='Thivya@123'){
      this.router.navigate(['homepage'])
      this.isUserLoggedIn=!this.isUserLoggedIn
      sessionStorage.setItem('userloggedin',JSON.stringify(this.isUserLoggedIn))
      console.log("user")
      window.location.reload
    }else{
      alert("invalid password or invalid emailid ")
    }
  }

}
