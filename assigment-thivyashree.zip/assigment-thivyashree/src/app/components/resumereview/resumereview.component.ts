import { Component } from '@angular/core';

@Component({
  selector: 'app-resumereview',
  templateUrl: './resumereview.component.html',
  styleUrls: ['./resumereview.component.css']
})
export class ResumereviewComponent {

}
