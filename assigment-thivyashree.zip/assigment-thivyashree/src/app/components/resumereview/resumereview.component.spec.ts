import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResumereviewComponent } from './resumereview.component';

describe('ResumereviewComponent', () => {
  let component: ResumereviewComponent;
  let fixture: ComponentFixture<ResumereviewComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ResumereviewComponent]
    });
    fixture = TestBed.createComponent(ResumereviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
