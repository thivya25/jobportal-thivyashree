import { Component } from '@angular/core';
import { Company } from 'src/app/dao/company';

@Component({
  selector: 'app-jobapplication',
  templateUrl: './jobapplication.component.html',
  styleUrls: ['./jobapplication.component.css']
})
export class JobapplicationComponent {
  job:Company;
  datas:any[]=[];
  records:any[]=[]
  
  ngOnInit(){
    let data= JSON.parse(localStorage.getItem('1'));
    let data2= JSON.parse(localStorage.getItem('2'));
    let data3= JSON.parse(localStorage.getItem('3'));
    let data4= JSON.parse(localStorage.getItem('4'));
    let data5= JSON.parse(localStorage.getItem('5'));
    let data6= JSON.parse(localStorage.getItem('6'));
     
      this.datas.push(data,data2,data3,data4,data5,data6)
    this.records=this.datas.filter(j=>j.status==="applied")
  }

}
