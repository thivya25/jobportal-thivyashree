import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { HomepageComponent } from './components/homepage/homepage.component';
import { LandingpageComponent } from './components/landingpage/landingpage.component';
import { FormsModule } from '@angular/forms';
import { FooterComponent } from './components/footer/footer.component';
import { MockinterviewComponent } from './components/mockinterview/mockinterview.component';
import { JobdetailsComponent } from './components/jobdetails/jobdetails.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { ResumereviewComponent } from './components/resumereview/resumereview.component';
import { JobapplicationComponent } from './components/jobapplication/jobapplication.component';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomepageComponent,
    LandingpageComponent,
    FooterComponent,
    MockinterviewComponent,
    JobdetailsComponent,
    NavbarComponent,
    ResumereviewComponent,
    JobapplicationComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
