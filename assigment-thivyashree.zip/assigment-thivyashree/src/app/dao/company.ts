export class Company {
jobrole: any;
    constructor(
        public companyid:string,
        public companyname:string,
        public jobroles:string,
        public jobdescription:string,
        public status:string,
        public location:string,
        public experience:string,
        public salary:string,
        public url:string

    ){}
}
